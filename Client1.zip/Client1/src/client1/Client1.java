/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package client1;

import ee.ttu.idu0075._2015.ws.concert.AddPerformerRequest;
import ee.ttu.idu0075._2015.ws.concert.GetPerformerRequest;
import ee.ttu.idu0075._2015.ws.concert.PerformerType;
import java.math.BigInteger;

/**
 *
 * @author Mussud
 */
public class Client1 {

   
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args)
    
    {
      AddPerformerRequest addRequest = new AddPerformerRequest();
        addRequest.setToken("salajane");
        addRequest.setName("ACDC");
        addRequest.setEmail("ACDC@mail.ee");
        addRequest.setRequestCode(BigInteger.ONE);
        addRequest.setPhone(BigInteger.ONE);
        PerformerType addperformer = addPerformer(addRequest);
        
        GetPerformerRequest performerRequest = new GetPerformerRequest();
        performerRequest.setToken("salajane");
        performerRequest.setId(addperformer.getPerformerId());
        PerformerType performer = getPerformer(performerRequest);
        System.out.println(performer.getName());
    }

    private static PerformerType addPerformer(ee.ttu.idu0075._2015.ws.concert.AddPerformerRequest parameter) 
    {
        ee.ttu.idu0075._2015.ws.concert.ConcertService service = new ee.ttu.idu0075._2015.ws.concert.ConcertService();
        ee.ttu.idu0075._2015.ws.concert.ConcertPortType port = service.getConcertPort();
        return port.addPerformer(parameter);
    }

    private static PerformerType getPerformer(ee.ttu.idu0075._2015.ws.concert.GetPerformerRequest parameter)
    {
        ee.ttu.idu0075._2015.ws.concert.ConcertService service = new ee.ttu.idu0075._2015.ws.concert.ConcertService();
        ee.ttu.idu0075._2015.ws.concert.ConcertPortType port = service.getConcertPort();
        return port.getPerformer(parameter);
    }
    
}
